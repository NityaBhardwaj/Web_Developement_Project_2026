from django.db import models

class Faculty(models.Model):
    faculty_id = models.AutoField(primary_key=True)
    scopus_author_id = models.CharField(max_length=50)
    name = models.CharField(max_length=100)
    affiliation = models.CharField(max_length=200)
    email = models.EmailField()
    research_area = models.CharField(max_length=200)
    total_citations = models.IntegerField(default=0)
    h_index = models.IntegerField(default=0)

    def __str__(self):
        return self.name
    
class Publication(models.Model):
    publication_id = models.AutoField(primary_key=True)
    scopus_author_id = models.CharField(max_length=50)
    title = models.CharField(max_length=300)
    journal_name = models.CharField(max_length=200)
    publication_year = models.IntegerField()
    citation_count = models.IntegerField(default=0)
    document_type = models.CharField(max_length=50)
    doi = models.CharField(max_length=100)

class AuthorPublication(models.Model):
    faculty = models.ForeignKey(Faculty, on_delete=models.CASCADE)
    publication = models.ForeignKey(Publication, on_delete=models.CASCADE)
    author_position = models.IntegerField()

class User(models.Model):
    username = models.CharField(max_length=100)
    password = models.CharField(max_length=200)
    role = models.CharField(max_length=50)
    linked_faculty = models.ForeignKey(Faculty, on_delete=models.CASCADE)