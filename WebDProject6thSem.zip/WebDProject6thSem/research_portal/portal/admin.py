from django.contrib import admin
from .models import Faculty, Publication, AuthorPublication, User

admin.site.register(Faculty)
admin.site.register(Publication)
admin.site.register(AuthorPublication)
admin.site.register(User)