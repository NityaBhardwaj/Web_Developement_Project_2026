from django.shortcuts import render

def login_view(request):
    return render(request, 'portal/login.html')

def dashboard_view(request):
    return render(request, 'portal/dashboard.html')