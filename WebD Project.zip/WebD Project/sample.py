from scholarly import scholarly

# Search query
query = "machine learning healthcare"

search_results = scholarly.search_pubs(query)

# Fetch first 5 papers
papers = []
for i in range(5):
    paper = next(search_results)

    paper_data = {
        "title": paper.get("bib", {}).get("title"),
        "authors": paper.get("bib", {}).get("author"),
        "year": paper.get("bib", {}).get("pub_year"),
        "abstract": paper.get("bib", {}).get("abstract"),
        "citations": paper.get("num_citations"),
        "url": paper.get("pub_url")
    }

    papers.append(paper_data)

# Print results
for p in papers:
    print("\n------------------------")
    for k, v in p.items():
        print(f"{k}: {v}")
